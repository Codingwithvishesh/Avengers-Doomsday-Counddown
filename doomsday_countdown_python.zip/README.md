# Avengers: Doomsday - The Last Countdown (Python)
Run: `python doomsday_countdown.py` (full 1080x1920) or `--width 540` for a fast preview.
Change release date: edit `RELEASE` at the top of the script.
Needs: numpy, opencv-python, pillow, scipy, ffmpeg on PATH. Full render takes ~13 min on 1 CPU; use `--jobs 4` to speed up.
Fonts: Inter (SIL OFL) bundled in ./fonts.
